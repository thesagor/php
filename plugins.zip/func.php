//write a simple wordpress plugin who will display a message in the footer of the website


// <?php
// /*
// Plugin Name: Footer Message
// Description: This plugin will display a message in the footer of the website
// Version: 1.0




function my_footer_message() {
	echo "This is my footer message";
}
add_action('wp_footer', 'my_footer_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the sidebar of the website

function my_sidebar_message() {
	echo "This is my sidebar message";
}
add_action('wp_sidebar', 'my_sidebar_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the header of the website

function my_header_message() {
	echo "This is my header message";
}
add_action('wp_header', 'my_header_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the content of the website

function my_content_message() {
	echo "This is my content message";
}
add_action('wp_content', 'my_content_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the single post of the website

function my_single_post_message() {
	echo "This is my single post message";
}
add_action('wp_single_post', 'my_single_post_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the page of the website

function my_page_message() {
	echo "This is my page message";
}
add_action('wp_page', 'my_page_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the category of the website

function my_category_message() {
	echo "This is my category message";
}
add_action('wp_category', 'my_category_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the archive of the website

function my_archive_message() {
	echo "This is my archive message";
}
add_action('wp_archive', 'my_archive_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the tag of the website

function my_tag_message() {
	echo "This is my tag message";
}
add_action('wp_tag', 'my_tag_message');
// Path: func.php
//write a simple wordpress plugin who will display a message in the search of the website

function my_search_message() {
	echo "This is my search message";
}
add_action('wp_search', 'my_search_message');
// Path: func.php
//write a simple wordpress plugin who will display a message i
function my_plugin_styles() {
    wp_enqueue_style( 'my-plugin-styles', plugins_url( 'style.css', __FILE__ ) );
}




